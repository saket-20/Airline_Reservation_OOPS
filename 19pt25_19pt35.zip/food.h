#ifndef Food_h
#define Food_h
class Food
{
protected:
    char drinks[20];
};
#endif
