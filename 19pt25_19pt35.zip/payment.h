#ifndef payment_h
#define payment_h

class Payment//abstract class
{
public:
    virtual void pay()=0;//pure virtual function
};
#endif // payment_h
